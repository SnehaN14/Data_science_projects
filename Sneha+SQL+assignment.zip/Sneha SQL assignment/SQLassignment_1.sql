-- SQL ASSIGNMENT 
-- STOCK MARKET ANALYSIS

-- create tables bajaj_auto, eicher_motors, hero_motocorp, infosys, tcs, tvs_motors in assignment schema

-- 1. bajaj_auto

create table if not exists `bajaj_auto` (
    `date` date,
    `open_price` decimal(10 , 2 ),
    `high_Price` decimal(10 , 2 ),
    `low_Price` decimal(10 , 2 ),
    `close_Price` decimal(10 , 2 ),
    `wap_price` decimal(10 , 2 ),
    `no_of_shares` bigint,
    `no_of_trades` bigint,
    `total_turnover` bigint,
    `deliverable_qty` bigint,
    `percent_dqty_to_tqty` decimal(4 , 2 ),
    `spread_high_low` decimal(10 , 2 ),
    `spread_close_open` decimal(10 , 2 )
);

-- Loading data from Bajaj Auto csv file into table baja_auto

load data infile 'D:/Assignment/Bajaj Auto.csv'
	into table bajaj_auto
	fields terminated by ','
	lines terminated by '\n'
	ignore 1 lines
	(@date, open_price, high_Price, low_Price, close_Price, wap_price, no_of_shares, no_of_trades, total_turnover, 
	@deliverable_qty, @percent_dqty_to_tqty, spread_high_low, spread_close_open)
set 
	date = str_to_date(@date,'%d-%M-%Y'),
	deliverable_qty = nullif(@deliverable_qty,''),
	percent_dqty_to_tqty = nullif(@percent_dqty_to_tqty,'') ;
    
-- creating table eicher_motors and loading data from Eicher Motors.csv into it 

create table if not exists eicher_motors like bajaj_auto;

load data infile 'D:/Assignment/Eicher Motors.csv'
	into table eicher_motors
	fields terminated by ','
	lines terminated by '\n'
	ignore 1 lines
	(@date, open_price, high_Price, low_Price, close_Price, wap_price, no_of_shares, no_of_trades, total_turnover, 
	@deliverable_qty, @percent_dqty_to_tqty, spread_high_low, spread_close_open)
set 
	date = str_to_date(@date,'%d-%M-%Y'),
	deliverable_qty = nullif(@deliverable_qty,''),
	percent_dqty_to_tqty = nullif(@percent_dqty_to_tqty,'') ;


-- creating table hero_motocorps and loading data from Hero Motocorp.csv into it

create table if not exists hero_motocorp like bajaj_auto;

load data infile 'D:/Assignment/Hero Motocorp.csv'
	into table hero_motocorp
	fields terminated by ','
	lines terminated by '\n'
	ignore 1 lines
	(@date, open_price, high_Price, low_Price, close_Price, wap_price, no_of_shares, no_of_trades, total_turnover, 
	@deliverable_qty, @percent_dqty_to_tqty, spread_high_low, spread_close_open)
set 
	date = str_to_date(@date,'%d-%M-%Y'),
	deliverable_qty = nullif(@deliverable_qty,''),
	percent_dqty_to_tqty = nullif(@percent_dqty_to_tqty,'') ;

-- creating table infosys and loading data from Infosys.csv into it

create table if not exists infosys like bajaj_auto; 

load data infile 'D:/Assignment/Infosys.csv'
	into table infosys
	fields terminated by ','
	lines terminated by '\n'
	ignore 1 lines
	(@date, open_price, high_Price, low_Price, close_Price, wap_price, no_of_shares, no_of_trades, total_turnover, 
	@deliverable_qty, @percent_dqty_to_tqty, spread_high_low, spread_close_open)
set 
	date = str_to_date(@date,'%d-%M-%Y'),
	deliverable_qty = nullif(@deliverable_qty,''),
	percent_dqty_to_tqty = nullif(@percent_dqty_to_tqty,'') ;

-- creating table tcs and loading data from TCS.csv into it

create table if not exists tcs like bajaj_auto;

load data infile 'D:/Assignment/TCS.csv'
	into table tcs
	fields terminated by ','
	lines terminated by '\n'
	ignore 1 lines
	(@date, open_price, high_Price, low_Price, close_Price, wap_price, no_of_shares, no_of_trades, total_turnover, 
	@deliverable_qty, @percent_dqty_to_tqty, spread_high_low, spread_close_open)
set 
	date = str_to_date(@date,'%d-%M-%Y'),
	deliverable_qty = nullif(@deliverable_qty,''),
	percent_dqty_to_tqty = nullif(@percent_dqty_to_tqty,'') ;
    
 -- creating table tvs_motors and loading data from TvS Motors.csv into it   
 
 create table if not exists tvs_motors like bajaj_auto; 
 
 load data infile 'D:/Assignment/TVS Motors.csv'
	into table tvs_motors
	fields terminated by ','
	lines terminated by '\n'
	ignore 1 lines
	(@date, open_price, high_Price, low_Price, close_Price, wap_price, no_of_shares, no_of_trades, total_turnover, 
	@deliverable_qty, @percent_dqty_to_tqty, spread_high_low, spread_close_open)
set 
	date = str_to_date(@date,'%d-%M-%Y'),
	deliverable_qty = nullif(@deliverable_qty,''),
	percent_dqty_to_tqty = nullif(@percent_dqty_to_tqty,'') ;

-- -- Question 1
-- create table bajaj1, eicher1, hero1, infosys1, tcs1, tvs1 for 20 day and 50 day moving average

drop table if exists bajaj1, eicher1, hero1, infosys1, tcs1, tvs1;

create table `bajaj1` (
    `Date` date,
    `Close Price` decimal(10 , 2 ),
    `20 Day MA` decimal(10 , 2 ),
    `50 Day MA` decimal(10 , 2 )
    
); 

insert into bajaj1 (`Date` , `Close Price`, `20 Day MA`, `50 Day MA` )(
 select date, close_Price,
 avg(close_Price) over (order by date rows 19 preceding),
 avg(close_Price) over (order by date rows 49 preceding)
 from bajaj_auto
 );


create table `eicher1` (
    `Date` date,
    `Close Price` decimal(10 , 2 ),
    `20 Day MA` decimal(10 , 2 ),
    `50 Day MA` decimal(10 , 2 )
    
); 

insert into eicher1 (`Date` , `Close Price`, `20 Day MA`, `50 Day MA` )(
 select date, close_Price,
 avg(close_Price) over (order by date rows 19 preceding),
 avg(close_Price) over (order by date rows 49 preceding)
 from eicher_motors
 );
 
 create table `hero1` (
    `Date` date,
    `Close Price` decimal(10 , 2 ),
    `20 Day MA` decimal(10 , 2 ),
    `50 Day MA` decimal(10 , 2 )
    
); 

insert into hero1 (`Date` , `Close Price`, `20 Day MA`, `50 Day MA` )(
 select date, close_Price,
 avg(close_Price) over (order by date rows 19 preceding),
 avg(close_Price) over (order by date rows 49 preceding)
 from hero_motocorp
 );
 
 create table `infosys1` (
    `Date` date,
    `Close Price` decimal(10 , 2 ),
    `20 Day MA` decimal(10 , 2 ),
    `50 Day MA` decimal(10 , 2 )
    
); 

insert into infosys1 (`Date` , `Close Price`, `20 Day MA`, `50 Day MA` )(
 select date, close_Price,
 avg(close_Price) over (order by date rows 19 preceding),
 avg(close_Price) over (order by date rows 49 preceding)
 from infosys
 );
 
 create table `tcs1` (
    `Date` date,
    `Close Price` decimal(10 , 2 ),
    `20 Day MA` decimal(10 , 2 ),
    `50 Day MA` decimal(10 , 2 )
    
);  

insert into tcs1 (`Date` , `Close Price`, `20 Day MA`, `50 Day MA` )(
 select date, close_Price,
 avg(close_Price) over (order by date rows 19 preceding),
 avg(close_Price) over (order by date rows 49 preceding)
 from tcs
 );
 
 create table `tvs1` (
    `Date` date,
    `Close Price` decimal(10 , 2 ),
    `20 Day MA` decimal(10 , 2 ),
    `50 Day MA` decimal(10 , 2 )
    
);   

insert into tvs1 (`Date` , `Close Price`, `20 Day MA`, `50 Day MA` )(
 select date, close_Price,
 avg(close_Price) over (order by date rows 19 preceding),
 avg(close_Price) over (order by date rows 49 preceding)
 from tvs_motors
 );
 
 -- Question2 Creating Master table
 
 
 drop table if exists Master_Table;
 
 create table Master_Table(
 `Date` date,
 `Bajaj` decimal(10,2),
 `TCS`   decimal(10,2),
 `TVS`   decimal(10,2),
 `Infosys` decimal(10,2),
 `Eicher`  decimal(10,2),
 `Hero`    decimal(10,2)
 );
 
 
 insert into Master_Table(
 with Master_Table_Temp as(
 select b.date as Date, b.close_Price as Bajaj, tc.close_Price as TCS, tv.close_Price as TVS,
 i.close_Price as Infosys, e.close_Price as Eicher, h.close_price as Hero
 from bajaj_auto b inner join TCS tc on tc.date=b.date
 inner join tvs_motors tv on tv.date=b.date
 inner join infosys i on i.date=b.date
 inner join eicher_motors e on e.date=b.date
 inner join hero_motocorp h on h.date=b.date
 )
 select * from Master_Table_temp
 );
 
 
 -- Question 3 Generating signals
 
 drop table if exists bajaj2, eicher2, hero2, infosys2, tcs2, tvs2;
 
 -- creating table for signal generation
 
 create table bajaj2(
 `Date` date,
 `Close Price` decimal(10,2),
 `Signal` varchar(60)
 );
 
 
 -- Inserting data into bajaj2
 
 insert into bajaj2(`Date`,`Close Price`, `Signal`)
(

with temp_bajaj2 as 
(
select *,
row_number() over (order by date) as rownumber,
case
    when `20 Day MA` > `50 Day MA` and lag(`20 Day MA`) over() < lag(`50 Day MA`) over() then 'Buy'
	when `20 Day MA` < `50 Day MA` and lag(`20 Day MA`) over() > lag(`50 Day MA`) over() then 'Sell'
    
    else 'hold'
end as `Signal`
from bajaj1
)
select `Date`,`Close Price`, `Signal`
from  temp_bajaj2 where rownumber>49
);

-- creating tables  for remaining  stocks and inserting data into it
create table eicher2 like bajaj2;

insert into eicher2(`Date`,`Close Price`, `Signal`)
(

with temp_eicher2 as 
(
select *,
row_number() over (order by date) as rownumber,
case
    when `20 Day MA` > `50 Day MA` and lag(`20 Day MA`,1) over() < lag(`50 Day MA`,1) over() then 'Buy'
	when `20 Day MA` < `50 Day MA` and lag(`20 Day MA`,1) over() > lag(`50 Day MA`,1) over() then 'Sell'
    
    else 'hold'
end as `Signal`
from eicher1
)
select `Date`,`Close Price`, `Signal`
from  temp_eicher2 where rownumber>49
);

create table hero2 like bajaj2;

insert into hero2(`Date`,`Close Price`, `Signal`)
(

with temp_hero2 as 
(
select *,
row_number() over (order by date) as rownumber,
case
    when `20 Day MA` > `50 Day MA` and lag(`20 Day MA`) over() < lag(`50 Day MA`) over() then 'Buy'
	when `20 Day MA` < `50 Day MA` and lag(`20 Day MA`) over() > lag(`50 Day MA`) over() then 'Sell'
    
    else 'hold'
end as `Signal`
from hero1
)
select `Date`,`Close Price`, `Signal`
from  temp_hero2 where rownumber>49
);


create table infosys2 like bajaj2;

insert into infosys2(`Date`,`Close Price`, `Signal`)
(

with temp_infosys2 as 
(
select *,
row_number() over (order by date) as rownumber,
case
    when `20 Day MA` > `50 Day MA` and lag(`20 Day MA`) over() < lag(`50 Day MA`) over() then 'Buy'
	when `20 Day MA` < `50 Day MA` and lag(`20 Day MA`) over() > lag(`50 Day MA`) over() then 'Sell'
    
    else 'hold'
end as `Signal`
from infosys1
)
select `Date`,`Close Price`, `Signal`
from  temp_infosys2 where rownumber>49
);

create table tcs2 like bajaj2;

insert into tcs2(`Date`,`Close Price`, `Signal`)
(

with temp_tcs2 as 
(
select *,
row_number() over (order by date) as rownumber,
case
    when `20 Day MA` > `50 Day MA` and lag(`20 Day MA`) over() < lag(`50 Day MA`) over() then 'Buy'
	when `20 Day MA` < `50 Day MA` and lag(`20 Day MA`) over() > lag(`50 Day MA`) over() then 'Sell'
    
    else 'hold'
end as `Signal`
from tcs1
)
select `Date`,`Close Price`, `Signal`
from  temp_tcs2 where rownumber>49
);

create table tvs2 like bajaj2;

insert into tvs2(`Date`,`Close Price`, `Signal`)
(

with temp_tvs2 as 
(
select *,
row_number() over (order by date) as rownumber,
case
    when `20 Day MA` > `50 Day MA` and lag(`20 Day MA`) over() < lag(`50 Day MA`) over() then 'Buy'
	when `20 Day MA` < `50 Day MA` and lag(`20 Day MA`) over() > lag(`50 Day MA`) over() then 'Sell'
    
    else 'hold'
end as `Signal`
from tvs1
)
select `Date`,`Close Price`, `Signal`
from  temp_tvs2 where rownumber>49
);

 -- Question 4 Creating Bajaj stock function 
 
 drop function if exists Bajaj_stock; 
 
create function Bajaj_stock(d date)
returns varchar(20) deterministic
return (select `Signal` from bajaj2 where date=d);

-- check whether the function is running

select Bajaj_stock('2017-04-20') as Signal_check;

 
